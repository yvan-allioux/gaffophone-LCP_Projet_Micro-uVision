#include "lpc17xx.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_libcfg_default.h"
#include "lpc17xx_timer.h"
#include "touch\ili_lcd_general.h"
#include "touch\lcd_api.h"
#include "affichagelcd.h"
#include "touch\touch_panel.h"
#include "lpc17xx_i2c.h"
#include <stdio.h>

//#include "globaldec.h"

//INITIALISATION I2C
void init_i2c(void){
	//I2C_Init(LPC_I2C0, 250000); // freq a 250 khz
	I2C_Init(LPC_I2C0, 500000); // freq a 500 khz
	I2C_Cmd(LPC_I2C0,ENABLE); // aprouve les operation sur l I2C
}


//LECTURE DE LA MEMOIRE
void i2c_eeprom_read(uint16_t addr, uint8_t* data, int length)
{
	//i2c_eeprom_read(0, &varMemoire, sizeof(varMemoire));
	
	I2C_M_SETUP_Type config; // config I2C
	uint8_t addr_ligne = addr & 0xFF;
	config.sl_addr7bit = 0x50 | (addr >> 8); // 0101 | addr >> 8 pour ne récupérer que les 3 bits de poids fort de l'adresse de mémoire
		
	config.tx_data = &addr_ligne;
	config.tx_count = 0;
	config.tx_length = 1;
	
	config.rx_data = data;
	config.rx_length = length;

	// Nombre de retransmission à zéro de base et maximum 3
	config.retransmissions_max = 3;
	config.retransmissions_count = 0;
	config.status = 0;
	
	I2C_MasterTransferData(LPC_I2C0, &config, I2C_TRANSFER_POLLING);
	
}


//ECRITURE DANS LA MEMOIRE
void i2c_eeprom_write(uint16_t addr, uint8_t* data, int length)
{
	//i2c_eeprom_write(0, &varMemoire, sizeof(varMemoire));
	
	int i;
	uint8_t data_to_write[255];//tableau que on va envoyer pour l'ecriture case de taille 8bit
	I2C_M_SETUP_Type config; // config I2C initialisation de la structure pour la configuration
	
	// 0101 | adresseFlash >> 8 pour ne récupérer que les 3 bits de poids fort de l'adresse de mémoire
	config.sl_addr7bit = 0x50 | (addr >> 8); //0x50 = 1010000 en bianire, on decal de 8 (pour avoir les 4bit de pois for) pour avoir le bit de pois faible a 0 ou 1 qui est automatiquement mis si ecriture ou lecture

	data_to_write[0] = ((addr) & (0xFF)); // Récupération des lignes de la mémoire à transmettre dans les données, recuperation des bit de pois faible et mise dans la premiere case du tableau
	for(i=0; i < length; i++)
	{
		data_to_write[i+1] = data[i]; // Récupération des données à écrire
	}
	
	config.tx_data = data_to_write; // Données à écrire
	config.tx_count = 0; // Compteur des données à transmettre à 0
	config.tx_length = length + 1; // Taille de l'adresse + les données
	// Nombre de retransmission à zéro de base et maximum 3
	config.retransmissions_max = 3;
	config.retransmissions_count = 0;
	config.status = 0;
	
	I2C_MasterTransferData(LPC_I2C0, &config,I2C_TRANSFER_POLLING);
	
}