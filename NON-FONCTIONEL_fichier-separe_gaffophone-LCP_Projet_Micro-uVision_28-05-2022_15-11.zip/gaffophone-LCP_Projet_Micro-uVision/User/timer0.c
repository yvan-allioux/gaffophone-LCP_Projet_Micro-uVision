#include "lpc17xx.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_libcfg_default.h"
#include "lpc17xx_timer.h"
#include "touch\ili_lcd_general.h"
#include "touch\lcd_api.h"
#include "affichagelcd.h"
#include "touch\touch_panel.h"
#include "lpc17xx_i2c.h"
#include <stdio.h>

#include "globaldec.h"

#define precision 50 // précion des temps en microsecondes
#define demie_periode 10 // duree de la demie-periode du signal en ms, plus c'est eleve plus c'est grave

//INITIALISATION DU TIMER
void initTimer()
{

	//-----Déclaration des structures

	//TP : Timer Precision, pour timer mode et precision
	TIM_TIMERCFG_Type timer;
	// TM : Timer Match, pour timer match
	TIM_MATCHCFG_Type match;
	

	//-----Initialisation des du mode timer et de la précision du timer
	
	// 0 ou 1 (type enum)
	timer.PrescaleOption = TIM_PRESCALE_USVAL; 
	
	// valeur donnee en micro-seconde, précion du temps en microsecondes
	timer.PrescaleValue = precision ;

	// Initialisation des registres
	TIM_Init(LPC_TIM0,TIM_TIMER_MODE,&timer);
	
	
	//-----Initialisation des actions à suivre lors d'un match
	 
	// utilisation du registre MR0
	match.MatchChannel = 0;
	
	// temps d'une demi-période
	match.MatchValue = demie_periode;
	
	// interruption à chaque match = actif
	match.IntOnMatch = ENABLE;
	
	// arrêt à chaque match : inactif
	match.StopOnMatch = DISABLE;
	
	// reset TC à chaque match : actif
	match.ResetOnMatch = ENABLE;
	
	// inversion de l'état à chaque match
	match.ExtMatchOutputType = TIM_EXTMATCH_TOGGLE;
	//match.ExtMatchOutputType = TIM_EXTMATCH_NOTHING;
	
	//Application de la configuration du match
	TIM_ConfigMatch(LPC_TIM0, &match);
	
	// Autorisation NVIC d'interruption du traitant "TIMER0_IRQn"
	NVIC_EnableIRQ(TIMER0_IRQn);
	 
	//-----Lancement du timer
	 
	TIM_Cmd(LPC_TIM0, ENABLE);
	
	return;
}


//FONCTION APELE LOR DUNE INTERUPTION
void TIMER0_IRQHandler ()
{
		
			if (musiqueCounter >= 100000) {
				musiqueCounter = 0;
			}else{
				musiqueCounter++;
			}
			
		if ( (GPIO_ReadValue(1)& (1<<9)) == 0 ){//si gpio du buzer est a 1 l'etindre sinon l'alumer...
				GPIO_SetValue(1, (1<<9));
		}else{
				GPIO_ClearValue(1, (1<<9));
		}
		TIM_ClearIntPending(LPC_TIM0, TIM_MR0_INT);
}