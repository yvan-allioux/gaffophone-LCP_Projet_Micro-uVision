//===========================================================//
// Projet Micro - INFO1 - ENSSAT - S2 2022      						 //
//===========================================================//
// File                : Programme de d�part
// Hardware Environment: Open1768
// Build Environment   : Keil �Vision
/*
TO DO
- bouton reset du scor
- timer pour jouer une melodie
- TIM_UpdateMatchValue(LPC_TIM0,0,100000000); // OK
- plusieur fichier

*/
//===========================================================//
/**
 *	@author yvan
 */

#include "lpc17xx.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_libcfg_default.h"
#include "lpc17xx_timer.h"
#include "touch\ili_lcd_general.h"
#include "touch\lcd_api.h"
#include "affichagelcd.h"
#include "touch\touch_panel.h"
#include "lpc17xx_i2c.h"
#include "globaldec.h"
#include <stdio.h>

// TIMER DEFFINE

#define countTactilCouleur 10 // nombre de micro activation sur une touche ecrant tactil d'afil�e pour consid�r� que c'est ok
// i2c
#include "lpc17xx_i2c.h"

#include "pinConnect.h"
#include "timer0.h"
#include "i2c.h"

// JOUER UNE MUSIQUE
void uneMusique(int time, int note)
{
	int n;
	// desactivation touch_read
	// pas besoin de desactivation si on apelle la fonction quand on clic sur un endrois
	TIM_Cmd(LPC_TIM0, ENABLE);

	musiqueCounter = 0;

	TIM_ResetCounter(LPC_TIM0);

	switch (note)
	{
	case 10:
		TIM_UpdateMatchValue(LPC_TIM0, 0, 22);
		dessiner_rect(10, 60, 110, 110, 2, 1, Black, Blue2);
		n = sprintf(chaine, "DO");
		LCD_write_english_string(60, 110, chaine, Black, Blue2);
		while (musiqueCounter <= time)
		{
		}
		dessiner_rect(10, 60, 110, 110, 2, 1, Black, Cyan); // DO
		n = sprintf(chaine, "DO");
		LCD_write_english_string(60, 110, chaine, Black, Cyan);
		break;
	case 20:
		TIM_UpdateMatchValue(LPC_TIM0, 0, 21);
		dessiner_rect(120, 60, 110, 110, 2, 1, Black, Blue2); // RE
		n = sprintf(chaine, "RE");
		LCD_write_english_string(170, 110, chaine, Black, Blue2);
		while (musiqueCounter <= time)
		{
		}
		dessiner_rect(120, 60, 110, 110, 2, 1, Black, Cyan); // RE
		n = sprintf(chaine, "RE");
		LCD_write_english_string(170, 110, chaine, Black, Cyan);
		break;
	case 30:
		TIM_UpdateMatchValue(LPC_TIM0, 0, 20);
		dessiner_rect(10, 170, 110, 110, 2, 1, Black, Blue2); // MI
		n = sprintf(chaine, "MI");
		LCD_write_english_string(60, 210, chaine, Black, Blue2);
		while (musiqueCounter <= time)
		{
		}
		dessiner_rect(10, 170, 110, 110, 2, 1, Black, Cyan); // MI
		n = sprintf(chaine, "MI");
		LCD_write_english_string(60, 210, chaine, Black, Cyan);
		break;
	case 40:
		TIM_UpdateMatchValue(LPC_TIM0, 0, 18);
		dessiner_rect(120, 170, 110, 110, 2, 1, Black, Blue2); // FA
		n = sprintf(chaine, "FA");
		LCD_write_english_string(170, 210, chaine, Black, Blue2);
		while (musiqueCounter <= time)
		{
		}
		dessiner_rect(120, 170, 110, 110, 2, 1, Black, Cyan); // FA
		n = sprintf(chaine, "FA");
		LCD_write_english_string(170, 210, chaine, Black, Cyan);
		break;
	case 50:
		// rien
		break;
	default:

		break;
	}
}

//===========================================================//
// Function: Main
//===========================================================//
int main(void)
{
	// variable de test pour v�rifier que on touche bien et pas juste un bug du tactil il fau cliquer countTactilCouleur de fois ... 10
	int countTactilJaune;
	int countTactilVert;
	int countTactilBleu;
	int countTactilRouge;
	int countTactilViolet;
	int countTactilJauneLoad;
	int countTactilReset;
	int countTactilPlay;

	int selectTactil; // variable qui permet de savoir quelle section du tactil est selection�e

	int tabVerif[11] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};				 // tableau pour enregistrer les frape de l'utilisateurs
	int clerDeLaLune[11] = {10, 10, 10, 20, 30, 20, 10, 30, 20, 20, 10}; // tableau pour verifier si le musicien a fais la bonne suite de touche

	int n;
	int i = 0;

	uint8_t varMemoire = 0; // variable qui compte le nombre de notte enclanch�e , utulis�e avec la memoire flash

	musiqueCounter = 0;

	selectTactil = 0;

	countTactilJaune = 0;
	countTactilVert = 0;
	countTactilBleu = 0;
	countTactilRouge = 0;
	countTactilViolet = 0;
	countTactilJauneLoad = 0;
	countTactilReset = 0;
	countTactilPlay = 0;

	initPinConnectBloc(); // initialisation gpio pin conecteur bloc ...
	initTimer();		  // initialisation du timer 0

	TIM_UpdateMatchValue(LPC_TIM0, 0, 100000000); // modification du match value du timer 0 a la vol�e pour changer la fr�quence de la musique

	init_i2c(); // initialisation de l'i2c

	lcd_Initializtion(); // init pinsel ecran et init LCD

	// titre
	n = sprintf(chaine, "gaffophone V0.47 yvan");
	LCD_write_english_string(32, 34, chaine, White, Blue);

	// save car�
	dessiner_rect(0, 0, 30, 30, 2, 1, Black, Magenta);
	dessiner_rect(7, 0, 15, 15, 2, 1, Black, White);
	dessiner_rect(9, 19, 10, 5, 2, 1, Black, Black);
	n = sprintf(chaine, "save");
	LCD_write_english_string(35, 7, chaine, Black, Blue);

	// load car�
	dessiner_rect(0 + 210, 0, 30, 30, 2, 1, Black, Yellow);
	dessiner_rect(7 + 210, 0, 15, 15, 2, 1, Black, White);
	dessiner_rect(9 + 210, 19, 10, 5, 2, 1, Black, Black);
	n = sprintf(chaine, "load");
	LCD_write_english_string(175, 7, chaine, Black, Blue);

	// play car�
	dessiner_rect(0 + 104, 0, 30, 30, 2, 1, Black, Cyan);
	dessiner_rect(9 + 104, 8, 8, 13, 2, 1, Black, Black);
	dessiner_rect(18 + 104, 11, 3, 7, 2, 1, Black, Black);
	n = sprintf(chaine, "p");
	LCD_write_english_string(9 + 104, 7, chaine, White, Black);

	// car�e touche de musique
	dessiner_rect(10, 60, 110, 110, 2, 1, Black, Cyan); // DO
	n = sprintf(chaine, "DO");
	LCD_write_english_string(60, 110, chaine, Black, Cyan);

	dessiner_rect(120, 60, 110, 110, 2, 1, Black, Cyan); // RE
	n = sprintf(chaine, "RE");
	LCD_write_english_string(170, 110, chaine, Black, Cyan);

	dessiner_rect(10, 170, 110, 110, 2, 1, Black, Cyan); // MI
	n = sprintf(chaine, "MI");
	LCD_write_english_string(60, 210, chaine, Black, Cyan);

	dessiner_rect(120, 170, 110, 110, 2, 1, Black, Cyan); // FA
	n = sprintf(chaine, "FA");
	LCD_write_english_string(170, 210, chaine, Black, Cyan);

	touch_init(); // initialisation du tactil

	TIM_ResetCounter(LPC_TIM0); // reset du timer car si on ne le fais pas et que on diminue la taille du match value cela peut faire crash le timer
	// TIM_UpdateMatchValue(LPC_TIM0,0,100000000);//on stop le bruir en metant une periode tr�s longue (pas propre comme methode mais bon ...)
	TIM_Cmd(LPC_TIM0, DISABLE);
	// TIM_Cmd(LPC_TIM0, ENABLE);
	uneMusique(100, 40);
	GPIO_SetDir(0, (1 << 0), 0); // la led est eteinte quand linitialisation est terminer

	while (1)
	{

		touch_read(); // actialisation des valeur du tactil

		// boucle pour detecter quelle zonze est touch�e
		if (((touch_x > 600) && (touch_x < 2000)) && ((touch_y > 2000) && (touch_y < 3000)))
		{ // jaune
			countTactilJaune++;
			if (selectTactil != 10 && countTactilJaune > countTactilCouleur)
			{
				TIM_Cmd(LPC_TIM0, ENABLE);
				selectTactil = 10;
				TIM_ResetCounter(LPC_TIM0);
				TIM_UpdateMatchValue(LPC_TIM0, 0, 22); // DO
				countTactilJaune = 0;

				dessiner_rect(10, 60, 110, 110, 2, 1, Black, Blue2);
				n = sprintf(chaine, "DO");
				LCD_write_english_string(60, 110, chaine, Black, Blue2);
			}
		}
		else if (((touch_x > 2100) && (touch_x < 3600)) && ((touch_y > 2000) && (touch_y < 3000)))
		{ // vert
			countTactilVert++;
			if (selectTactil != 20 && countTactilVert > countTactilCouleur)
			{
				TIM_Cmd(LPC_TIM0, ENABLE);
				selectTactil = 20;
				TIM_ResetCounter(LPC_TIM0);
				TIM_UpdateMatchValue(LPC_TIM0, 0, 21); // RE
				countTactilVert = 0;

				dessiner_rect(120, 60, 110, 110, 2, 1, Black, Blue2); // RE
				n = sprintf(chaine, "RE");
				LCD_write_english_string(170, 110, chaine, Black, Blue2);
			}
		}
		else if (((touch_x > 600) && (touch_x < 2000)) && ((touch_y > 700) && (touch_y < 1800)))
		{ // bleu
			countTactilBleu++;
			if (selectTactil != 30 && countTactilBleu > countTactilCouleur)
			{
				TIM_Cmd(LPC_TIM0, ENABLE);
				selectTactil = 30;
				TIM_ResetCounter(LPC_TIM0);
				TIM_UpdateMatchValue(LPC_TIM0, 0, 20); // MI
				countTactilBleu = 0;

				dessiner_rect(10, 170, 110, 110, 2, 1, Black, Blue2); // MI
				n = sprintf(chaine, "MI");
				LCD_write_english_string(60, 210, chaine, Black, Blue2);
			}
		}
		else if (((touch_x > 2100) && (touch_x < 3600)) && ((touch_y > 700) && (touch_y < 1800)))
		{ // rouge
			countTactilRouge++;
			if (selectTactil != 40 && countTactilRouge > countTactilCouleur)
			{
				TIM_Cmd(LPC_TIM0, ENABLE);
				selectTactil = 40;
				TIM_ResetCounter(LPC_TIM0);
				TIM_UpdateMatchValue(LPC_TIM0, 0, 18); // FA
				countTactilRouge = 0;

				dessiner_rect(120, 170, 110, 110, 2, 1, Black, Blue2); // FA
				n = sprintf(chaine, "FA");
				LCD_write_english_string(170, 210, chaine, Black, Blue2);
			}
		}
		else if (((touch_x > 100) && (touch_x < 800)) && ((touch_y > 3300) && (touch_y < 3800)))
		{ // VIOLET
			countTactilViolet++;
			if (selectTactil != 60 && countTactilViolet > countTactilCouleur)
			{
				GPIO_SetDir(0, (1 << 0), 1);
				selectTactil = 60;
				countTactilViolet = 0;
				i2c_eeprom_write(0, &varMemoire, sizeof(varMemoire)); // ECRITURE EN MEMOIRE SAUVEGARDE
				dessiner_rect(7, 0, 15, 15, 2, 1, Black, Red);
			}
		}
		else if (((touch_x > 3300) && (touch_x < 3900)) && ((touch_y > 3300) && (touch_y < 3800)))
		{ // JAUNE_LOAD
			countTactilJauneLoad++;
			if (selectTactil != 70 && countTactilJauneLoad > countTactilCouleur)
			{
				GPIO_SetDir(0, (1 << 0), 1);
				selectTactil = 70;
				countTactilJauneLoad = 0;
				i2c_eeprom_read(0, &varMemoire, sizeof(varMemoire)); // LECTURE EN MEMOIRE
				dessiner_rect(7 + 210, 0, 15, 15, 2, 1, Black, Red);
			}
		}
		else if ((touch_y > 100) && (touch_y < 490))
		{ // RESET
			countTactilReset++;
			if (selectTactil != 80 && countTactilReset > countTactilCouleur)
			{
				GPIO_SetDir(0, (1 << 0), 1);
				selectTactil = 80;
				countTactilReset = 0;
				varMemoire = 0; // reset du compteur
			}
		}
		else if (((touch_x > 1850) && (touch_x < 2450)) && ((touch_y > 3300) && (touch_y < 3800)))
		{ // PLAY
			countTactilPlay++;
			if (selectTactil != 90 && countTactilPlay > countTactilCouleur)
			{

				for (i = 0; i < 11; ++i)
				{
					if (tabVerif[i] != clerDeLaLune[i])
					{
						n = sprintf(chaine, "gaffophone NON VALIDE ");
						LCD_write_english_string(32, 34, chaine, Red, Blue);
						break;
					}
					else
					{
						if (i == 10)
						{
							n = sprintf(chaine, "gaffophone VALIDE     ");
							LCD_write_english_string(32, 34, chaine, Green, Blue);
						}
					}
				}

				GPIO_SetDir(0, (1 << 0), 1);

				// au cler de la lune 11 note
				uneMusique(300, 10);
				uneMusique(300, 10);
				uneMusique(300, 10);
				uneMusique(300, 20);
				uneMusique(600, 30);
				uneMusique(500, 20);
				uneMusique(300, 10);
				uneMusique(300, 30);
				uneMusique(300, 20);
				uneMusique(300, 20);
				uneMusique(500, 10);

				for (i = 0; i < 11; ++i)
				{
					tabVerif[i] = 0;
				}

				GPIO_SetDir(0, (1 << 0), 0);
				selectTactil = 90;
				countTactilPlay = 0;
			}
		}
		else
		{
			if (selectTactil != 50)
			{						  // pour ne passer que 1 fois ici quand on ne touche pas l'ecrant (detecte le lev�e de doit en gros)
				switch (selectTactil) // pour ne reaficher la couleur originale que d'un car�e
				{
				case 10:
					dessiner_rect(10, 60, 110, 110, 2, 1, Black, Cyan); // DO
					n = sprintf(chaine, "DO");
					LCD_write_english_string(60, 110, chaine, Black, Cyan);
					varMemoire++;
					for (i = 0; i < 11; ++i)
					{
						if (tabVerif[i] == 0)
						{
							tabVerif[i] = 10;
							break;
						}
					}

					break;
				case 20:
					dessiner_rect(120, 60, 110, 110, 2, 1, Black, Cyan); // RE
					n = sprintf(chaine, "RE");
					LCD_write_english_string(170, 110, chaine, Black, Cyan);
					varMemoire++;
					for (i = 0; i < 11; ++i)
					{
						if (tabVerif[i] == 0)
						{
							tabVerif[i] = 20;
							break;
						}
					}
					break;
				case 30:
					dessiner_rect(10, 170, 110, 110, 2, 1, Black, Cyan); // MI
					n = sprintf(chaine, "MI");
					LCD_write_english_string(60, 210, chaine, Black, Cyan);
					varMemoire++;
					for (i = 0; i < 11; ++i)
					{
						if (tabVerif[i] == 0)
						{
							tabVerif[i] = 30;
							break;
						}
					}
					break;
				case 40:
					dessiner_rect(120, 170, 110, 110, 2, 1, Black, Cyan); // FA
					n = sprintf(chaine, "FA");
					LCD_write_english_string(170, 210, chaine, Black, Cyan);
					varMemoire++;
					for (i = 0; i < 11; ++i)
					{
						if (tabVerif[i] == 0)
						{
							tabVerif[i] = 40;
							break;
						}
					}
					break;
				case 60: // violet
					dessiner_rect(7, 0, 15, 15, 2, 1, Black, White);
					break;
				case 70: // jaune load
					dessiner_rect(7 + 210, 0, 15, 15, 2, 1, Black, White);
					break;
				default:
					// rien
					break;
				}

				n = sprintf(chaine, "nb de note %d  ", varMemoire);
				LCD_write_english_string(60, 290, chaine, Black, Blue);

				TIM_ResetCounter(LPC_TIM0);
				// TIM_UpdateMatchValue(LPC_TIM0,0,100000000);
				TIM_Cmd(LPC_TIM0, DISABLE);

				selectTactil = 0;
				countTactilJaune = 0;
				countTactilVert = 0;
				countTactilBleu = 0;
				countTactilRouge = 0;
				countTactilViolet = 0;
				countTactilJauneLoad = 0;
				selectTactil = 50;

				GPIO_SetDir(0, (1 << 0), 0);

			} // fin detection lever doit de lecrant
		}

	} // fin while
}

//---------------------------------------------------------------------------------------------
#ifdef DEBUG
void check_failed(uint8_t *file, uint32_t line)
{
	while (1)
		;
}
#endif
