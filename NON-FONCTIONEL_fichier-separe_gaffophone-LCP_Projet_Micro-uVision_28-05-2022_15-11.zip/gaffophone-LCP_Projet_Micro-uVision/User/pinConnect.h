#ifndef _PINCONNECT_H
#define _PINCONNECT_H

void initPinConnectBloc();

#endif