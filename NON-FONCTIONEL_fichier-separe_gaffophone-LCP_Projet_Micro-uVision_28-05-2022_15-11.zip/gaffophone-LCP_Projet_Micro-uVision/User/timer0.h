#ifndef _TIMER0_H
#define _TIMER0_H

void initTimer();
void TIMER0_IRQHandler();

#endif