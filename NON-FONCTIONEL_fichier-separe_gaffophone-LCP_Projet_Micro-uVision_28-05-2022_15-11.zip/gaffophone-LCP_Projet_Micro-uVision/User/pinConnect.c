#include "lpc17xx.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_libcfg_default.h"
#include "lpc17xx_timer.h"
#include "touch\ili_lcd_general.h"
#include "touch\lcd_api.h"
#include "affichagelcd.h"
#include "touch\touch_panel.h"
#include "lpc17xx_i2c.h"
#include <stdio.h>

//INITIALISATION DU PIN CONECTEUR BLOCK (gpip pinsel ...)
void initPinConnectBloc()//----------------------------PIN CONNECT----
{
	//Déclaration des structures
	
	// declaration des structures de configuration
	PINSEL_CFG_Type pinLed; //initialisation d'une structure cette var a le nom pin
	PINSEL_CFG_Type pinBuz; //pour le buzer
		

	//Initialisation des informations de la Pin0.0 GPIO LED
	//PINSEL_CFG_Type a des valeur
	pinLed.Portnum = 0;
	pinLed.Pinnum = 0;
	pinLed.Funcnum = 0;
	pinLed.Pinmode = 0;
	pinLed.OpenDrain = 0;

	LPC_PINCON->PINSEL0 = 0; //congiguration du PINSEL
	LPC_PINCON->PINMODE0 = 0;
	

	//Initialisation des informations de la Pin1.9 GPIO BUZ
	//PINSEL_CFG_Type a des valeur 
	pinBuz.Portnum = 1;
	pinBuz.Pinnum = 9;
	pinBuz.Funcnum = 0;
	pinBuz.Pinmode = 0;
	pinBuz.OpenDrain = 0;

	LPC_PINCON->PINSEL2 = 0; // PINSEL mais du buzer 2 car c'est comme ça dans la doc, activation du pinsel
	LPC_PINCON->PINMODE0 = 0;

	//Initialisation des registres pour modifier le Pin Connect Block
	PINSEL_ConfigPin(&pinLed);//led
	PINSEL_ConfigPin(&pinBuz);//buz
	
	//Configuration du PIN Connect Block pour la mémoire
	LPC_PINCON->PINSEL1 |= (1 << 22); //on fais un declage de 22 à gauche 			000 0001 << 2 == 0000 0100
	LPC_PINCON->PINSEL1 |= (1 << 24);
	
	// Led en sortie du GPIO
	GPIO_SetDir(0, (1<<0), 1);
	// buz en sortie du GPIO
	GPIO_SetDir(1, (1<<9), 1);
	
	return;
}
