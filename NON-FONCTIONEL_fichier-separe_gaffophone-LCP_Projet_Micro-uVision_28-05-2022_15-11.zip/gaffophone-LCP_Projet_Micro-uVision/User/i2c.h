#ifndef _I2C_H
#define _I2C_H

#include "lpc17xx.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_libcfg_default.h"
#include "lpc17xx_timer.h"
#include "touch\ili_lcd_general.h"
#include "touch\lcd_api.h"
#include "affichagelcd.h"
#include "touch\touch_panel.h"
#include "lpc17xx_i2c.h"
#include <stdio.h>

void init_i2c();
void i2c_eeprom_read(uint16_t addr, uint8_t* data, int length);
void i2c_eeprom_write(uint16_t addr, uint8_t* data, int length);

#endif